#!/bin/bash
# ==========================================================================
# Generate PNG images from PlantUML files
# Requirements: Java installed, plantuml.jar in same directory
# Download plantuml.jar from: https://plantuml.com/download
# ==========================================================================

echo "============================================================"
echo "Generating PNG images from PlantUML files"
echo "============================================================"
echo ""

# Create images folder if it doesn't exist
mkdir -p images

# Check if plantuml.jar exists
if [ ! -f "plantuml.jar" ]; then
    echo "ERROR: plantuml.jar not found!"
    echo "Download it from: https://plantuml.com/download"
    echo "Place it in the same folder as this script."
    exit 1
fi

# Generate each diagram
diagrams=(
    "use_case_diagram.puml"
    "activity_diagram.puml"
    "communication_diagram.puml"
    "class_diagram.puml"
    "state_diagram.puml"
    "component_diagram.puml"
    "sequence_diagram.puml"
)

for diagram in "${diagrams[@]}"; do
    echo "Processing: $diagram"
    java -jar plantuml.jar -o images "$diagram"
done

echo ""
echo "============================================================"
echo "Done! Check the 'images' folder for PNG files."
echo "============================================================"

# List generated files
echo ""
echo "Generated files:"
ls -la images/*.png 2>/dev/null
