# UML Diagrams - Intelligent Personal Finance Management System

## Course: CSCI 6234 - Object-Oriented Design
## Reference: Martin Fowler's UML Distilled

---

## 📁 Diagram Files

| # | File Name | Diagram Type | Description |
|---|-----------|--------------|-------------|
| 1 | `use_case_diagram.puml` | Use Case Diagram | System functionality from user perspective |
| 2 | `activity_diagram.puml` | Activity Diagram | Transaction categorization workflow |
| 3 | `communication_diagram.puml` | Communication Diagram | Budget alert generation interactions |
| 4 | `class_diagram.puml` | Class Diagram | Domain model with design patterns |
| 5 | `state_diagram.puml` | State Diagram | Account & budget alert states |
| 6 | `component_diagram.puml` | Component Diagram | System architecture layers |
| 7 | `sequence_diagram.puml` | Sequence Diagram | Transaction import flow |

---

## 🎯 Design Patterns Demonstrated

| Pattern | Category | Diagram(s) |
|---------|----------|------------|
| **Strategy** | Behavioral | Class, Sequence, Activity |
| **Observer** | Behavioral | Class, Communication, Sequence |
| **Chain of Responsibility** | Behavioral | Class, Activity, Sequence |
| **State** | Behavioral | State, Class |
| **Factory Method** | Creational | Class, Communication, Sequence |
| **Adapter** | Structural | Class, Component, Sequence |
| **Repository** | Architectural | Class, Component |

---

## 📐 SOLID Principles

| Principle | Implementation |
|-----------|----------------|
| **S** - Single Responsibility | Each service handles one concern |
| **O** - Open/Closed | Strategy pattern for categorization |
| **L** - Liskov Substitution | Account subtypes interchangeable |
| **I** - Interface Segregation | Separate repository interfaces |
| **D** - Dependency Inversion | Services depend on abstractions |

---

## 🔧 How to Render

### Option 1: PlantUML Online
1. Go to https://www.plantuml.com/plantuml/uml/
2. Paste `.puml` content
3. Download PNG/SVG

### Option 2: VS Code
1. Install "PlantUML" extension
2. Open `.puml` file
3. Press `Alt+D` to preview

---

## 👥 Team Members
- Samarth Kundargi
- [Partner Name]

## 📅 Course
CSCI 6234 - Object-Oriented Design (Spring 2026)
